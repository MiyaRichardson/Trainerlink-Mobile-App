package com.trainerlink.ui.theme.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.trainerlink.R;

public class HomeFragment extends Fragment {

    public HomeFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        TextView welcomeText = view.findViewById(R.id.welcome_text);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String name = (user != null) ? user.getDisplayName() : null;

        if (name == null || name.isEmpty()) {
            name = "User";  // fallback
        }

        welcomeText.setText("Welcome back, " + name);

        return view;
    }
}


