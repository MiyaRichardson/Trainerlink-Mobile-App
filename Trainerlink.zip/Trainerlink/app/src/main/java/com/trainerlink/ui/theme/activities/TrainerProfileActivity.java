package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.trainerlink.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;

public class TrainerProfileActivity extends AppCompatActivity {

    private LinearLayout reviewListLayout;
    private EditText reviewInput;
    private RatingBar reviewRatingBar, averageRatingBar;
    private FirebaseUser currentUser;
    private boolean isPremiumUser = false; // Replace with real check later
    private List<Review> reviews = new ArrayList<>();

    class Review {
        String username;
        String text;
        float rating;

        Review(String username, String text, float rating) {
            this.username = username;
            this.text = text;
            this.rating = rating;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer_profile);

        // UI references
        TextView nameView = findViewById(R.id.trainerName);
        TextView areaView = findViewById(R.id.trainerArea);
        TextView specView = findViewById(R.id.trainerSpecialisation);
        TextView descView = findViewById(R.id.trainerDescription);
        ImageView image = findViewById(R.id.trainerImage);
        reviewListLayout = findViewById(R.id.reviewListLayout);
        reviewInput = findViewById(R.id.reviewInput);
        reviewRatingBar = findViewById(R.id.reviewRatingBar);
        averageRatingBar = findViewById(R.id.averageRatingBar);
        Button submitBtn = findViewById(R.id.submitReviewButton);

        // Dummy content for trainer
        String trainerName = getIntent().getStringExtra("trainerName");
        nameView.setText(trainerName);
        areaView.setText("Birmingham");
        specView.setText("Rehabilitation");
        descView.setText("Hi, I’m Alice, a certified personal trainer with over 7 years of experience specialising in rehabilitation fitness. I love helping clients build strength, improve endurance, and refine their routines. Whether you’re looking to break through a plateau or take your fitness to the next level..");
        image.setImageResource(R.drawable.trainer1_image);

        // Chat button
        Button chatButton = findViewById(R.id.chatButton);
        chatButton.setOnClickListener(v -> {
            Intent intent = new Intent(TrainerProfileActivity.this, PersonalChatActivity.class);
            intent.putExtra("trainerName", trainerName);
            startActivity(intent);
        });

        // Book button
        Button bookButton = findViewById(R.id.bookButton);
        bookButton.setOnClickListener(v -> {
            Intent intent = new Intent(TrainerProfileActivity.this, BookingActivity.class);
            intent.putExtra("trainerName", trainerName);
            startActivity(intent);
        });

        // Get current Firebase user
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        // Load dummy reviews
        loadDummyReviews();
        updateReviewDisplay();

        // Handle review submission
        submitBtn.setOnClickListener(v -> {
            String text = reviewInput.getText().toString().trim();
            float rating = reviewRatingBar.getRating();

            if (text.isEmpty() || rating == 0) {
                Toast.makeText(this, "Please enter both review and rating.", Toast.LENGTH_SHORT).show();
                return;
            }

            String username = "Anonymous";
            if (currentUser != null) {
                if (currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
                    username = currentUser.getDisplayName();
                } else if (currentUser.getEmail() != null) {
                    username = currentUser.getEmail().split("@")[0];
                }
            }

            reviews.add(0, new Review(username, text, rating));
            reviewInput.setText("");
            reviewRatingBar.setRating(0);
            updateReviewDisplay();
        });
    }

    private void loadDummyReviews() {
        reviews.add(new Review("FitnessFan99", "Very motivating sessions!", 5));
        reviews.add(new Review("JaneD", "Helped me recover from injury", 4));
        reviews.add(new Review("MoAli", "Great personality!", 5));
        reviews.add(new Review("Sam_S", "Flexible scheduling!", 4));
        reviews.add(new Review("Laura_W", "Would recommend to friends", 5));
    }

    private void updateReviewDisplay() {
        reviewListLayout.removeAllViews();

        float totalRating = 0;
        int count = 0;
        int maxToShow = isPremiumUser ? reviews.size() : Math.min(3, reviews.size());

        for (int i = 0; i < maxToShow; i++) {
            Review r = reviews.get(i);
            totalRating += r.rating;
            count++;

            // One TextView for stars and name
            TextView userInfo = new TextView(this);
            userInfo.setText("★ " + r.rating + " - " + r.username);
            userInfo.setTextSize(16f);
            userInfo.setPadding(0, 10, 0, 0);

            // One TextView for review text
            TextView reviewText = new TextView(this);
            reviewText.setText(r.text);
            reviewText.setPadding(0, 0, 0, 15);

            reviewListLayout.addView(userInfo);
            reviewListLayout.addView(reviewText);
        }


        if (count > 0) {
            float avg = totalRating / count;
            averageRatingBar.setRating(avg);
        } else {
            averageRatingBar.setRating(0);
        }
    }
}
