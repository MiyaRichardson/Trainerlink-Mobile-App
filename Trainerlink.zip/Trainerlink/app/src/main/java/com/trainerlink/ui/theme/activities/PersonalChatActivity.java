package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.trainerlink.R;
import com.trainerlink.ui.theme.models.Message;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PersonalChatActivity extends AppCompatActivity {

    private LinearLayout chatLayout;
    private EditText messageInput;
    private ImageView sendButton;
    private ScrollView scrollView;
    private ImageView backButton;
    private String currentTrainerName;

    public static boolean hasChattedWithAlice = false;
    private boolean trainerHasResponded = false;
    private List<Message> messages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_chat);

        chatLayout = findViewById(R.id.chatLayout);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);
        scrollView = findViewById(R.id.scrollView);
        backButton = findViewById(R.id.backButton);

        // Get trainer name passed from previous activity
        currentTrainerName = getIntent().getStringExtra("trainerName");

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("openChatFragment", true);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        sendButton.setOnClickListener(v -> {
            String text = messageInput.getText().toString().trim();
            if (text.isEmpty()) {
                Toast.makeText(PersonalChatActivity.this, "Please enter a message", Toast.LENGTH_SHORT).show();
                return;
            }

            long timestamp = System.currentTimeMillis();

            // Add user's message
            Message userMessage = new Message(text, true, timestamp);
            messages.add(userMessage);
            addMessageToView(userMessage);

            // Clear input
            messageInput.setText("");

            // Scroll to bottom
            scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));

            // Mark chat active so it shows in chat list
            hasChattedWithAlice = true;

            // Trainer auto-respond once after first user message
            if (!trainerHasResponded) {
                trainerHasResponded = true;
                new Handler().postDelayed(() -> {
                    long replyTimestamp = System.currentTimeMillis();
                    Message trainerReply = new Message("Hi! You don't need to bring anything 😊", false, replyTimestamp);
                    messages.add(trainerReply);
                    addMessageToView(trainerReply);
                    scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
                }, 60000); // 1 minute delay
            }
        });

        // If already chatted, load previous messages (demo-only)
        if (hasChattedWithAlice) {
            // For demo, just load the initial trainer reply and a user message
            // In real app, load from database or saved state

            // Clear existing views just in case
            chatLayout.removeAllViews();

            // Example demo messages:
            Message userMsg = new Message("Hello, do I need to bring anything to the session?", true, System.currentTimeMillis() - 120000);
            Message trainerMsg = new Message("Hi! You don't need to bring anything 😊", false, System.currentTimeMillis() - 60000);

            messages.add(userMsg);
            messages.add(trainerMsg);

            addMessageToView(userMsg);
            addMessageToView(trainerMsg);
        }
    }

    private void addMessageToView(Message message) {
        boolean isUser = message.isUser();

        TextView messageText = new TextView(this);
        messageText.setText(message.getText());
        messageText.setTextSize(16f);
        messageText.setPadding(20, 10, 20, 10);
        messageText.setTextColor(isUser ? Color.DKGRAY : Color.WHITE);
        messageText.setBackground(isUser ? getDrawable(R.drawable.bubble_user) : getDrawable(R.drawable.bubble_trainer));

        LinearLayout.LayoutParams messageParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        messageParams.gravity = isUser ? Gravity.END : Gravity.START;
        messageParams.setMargins(20, 10, 20, 0);
        messageText.setLayoutParams(messageParams);

        chatLayout.addView(messageText);

        // Timestamp TextView below message
        TextView timestampText = new TextView(this);
        timestampText.setText(formatTimestamp(message.getTimestamp()));
        timestampText.setTextSize(12f);
        timestampText.setTextColor(Color.GRAY);

        LinearLayout.LayoutParams tsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        tsParams.gravity = isUser ? Gravity.END : Gravity.START;
        tsParams.setMargins(20, 0, 20, 10);
        timestampText.setLayoutParams(tsParams);

        chatLayout.addView(timestampText);
    }

    private String formatTimestamp(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, TrainerProfileActivity.class);
        intent.putExtra("trainerName", currentTrainerName);
        startActivity(intent);
        finish();
    }
}
