package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.trainerlink.R;

public class LogoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout); // This is your XML with Yes/Cancel buttons

        Button confirmLogoutBtn = findViewById(R.id.confirmLogoutBtn);
        Button cancelLogoutBtn = findViewById(R.id.cancelLogoutBtn);

        confirmLogoutBtn.setOnClickListener(v -> {
            // Log out user
            FirebaseAuth.getInstance().signOut();
            // Go to login screen
            Intent intent = new Intent(LogoutActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
            startActivity(intent);
            finish();
        });

        cancelLogoutBtn.setOnClickListener(v -> {
            // Close the logout screen and return to previous screen
            finish();
        });
    }
}


