package com.trainerlink.ui.theme.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.trainerlink.R;
import com.trainerlink.ui.theme.models.Booking;

import java.util.List;

public class BookingAdapter extends RecyclerView.Adapter<BookingAdapter.BookingViewHolder> {

    private final List<Booking> bookings;
    private final Context context;

    public BookingAdapter(List<Booking> bookings, Context context) {
        this.bookings = bookings;
        this.context = context;
    }

    @NonNull
    @Override
    public BookingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_booking, parent, false);
        return new BookingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookingViewHolder holder, int position) {
        Booking booking = bookings.get(position);
        holder.trainerNameText.setText("Trainer: " + booking.getTrainerName());
        holder.dateText.setText("Date: " + booking.getSessionDate());
        holder.timeText.setText("Time: " + booking.getSessionTime());

        holder.deleteIcon.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Booking")
                    .setMessage("Are you sure you want to delete this booking?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        FirebaseFirestore.getInstance()
                                .collection("bookings")
                                .document(booking.getDocumentId())
                                .delete()
                                .addOnSuccessListener(unused -> {
                                    bookings.remove(position);
                                    notifyItemRemoved(position);
                                    Toast.makeText(context, "Booking deleted", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e ->
                                        Toast.makeText(context, "Failed to delete booking", Toast.LENGTH_SHORT).show());
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return bookings.size();
    }

    static class BookingViewHolder extends RecyclerView.ViewHolder {
        TextView trainerNameText, dateText, timeText;
        ImageView deleteIcon;

        public BookingViewHolder(@NonNull View itemView) {
            super(itemView);
            trainerNameText = itemView.findViewById(R.id.trainerNameText);
            dateText = itemView.findViewById(R.id.dateText);
            timeText = itemView.findViewById(R.id.timeText);
            deleteIcon = itemView.findViewById(R.id.deleteIcon);
        }
    }
}
