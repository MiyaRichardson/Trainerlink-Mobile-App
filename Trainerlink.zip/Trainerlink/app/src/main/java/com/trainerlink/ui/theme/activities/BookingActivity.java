package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.trainerlink.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class BookingActivity extends AppCompatActivity {

    private TextView headerText;
    private CalendarView calendarView;
    private ListView timeSlotsListView;
    private Button proceedButton;

    private String trainerName;
    private long selectedDateMillis = -1;
    private String selectedTimeSlot = null;

    private HashMap<String, ArrayList<String>> availabilityMap = new HashMap<>();
    private ArrayList<String> currentTimeSlots = new ArrayList<>();
    private ArrayAdapter<String> timeSlotsAdapter;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        headerText = findViewById(R.id.headerText);
        calendarView = findViewById(R.id.calendarView);
        timeSlotsListView = findViewById(R.id.timeSlotsListView);
        proceedButton = findViewById(R.id.proceedButton);

        trainerName = getIntent().getStringExtra("trainerName");
        if (trainerName == null) trainerName = "Trainer";

        headerText.setText("Book with " + trainerName);
        proceedButton.setEnabled(false);

        loadDummyAvailability();

        calendarView.setMinDate(System.currentTimeMillis());

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            String selectedDateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            selectedDateMillis = getDateMillis(year, month, dayOfMonth);

            if (availabilityMap.containsKey(selectedDateStr)) {
                updateTimeSlots(selectedDateStr);
                proceedButton.setEnabled(false);
                selectedTimeSlot = null;
            } else {
                Toast.makeText(this, "No availability on this date.", Toast.LENGTH_SHORT).show();
                currentTimeSlots.clear();
                timeSlotsAdapter.notifyDataSetChanged();
                proceedButton.setEnabled(false);
                selectedTimeSlot = null;
            }
        });

        timeSlotsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, currentTimeSlots);
        timeSlotsListView.setAdapter(timeSlotsAdapter);
        timeSlotsListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        timeSlotsListView.setOnItemClickListener((parent, view, position, id) -> {
            selectedTimeSlot = currentTimeSlots.get(position);
            proceedButton.setEnabled(true);
        });

        proceedButton.setOnClickListener(v -> {
            if (selectedDateMillis == -1 || selectedTimeSlot == null) {
                Toast.makeText(this, "Please select date and time slot.", Toast.LENGTH_SHORT).show();
                return;
            }

            String bookingDateStr = dateFormat.format(new Date(selectedDateMillis)); // e.g. 2025-06-05

// Pretty display format for confirmation screen
            SimpleDateFormat prettyFormat = new SimpleDateFormat("dd MMMM yyyy", Locale.US);
            String displayDateStr = prettyFormat.format(new Date(selectedDateMillis)); // e.g. 05 June 2025

            Intent intent = new Intent(BookingActivity.this, PaymentActivity.class);
            intent.putExtra("trainerName", trainerName);
            intent.putExtra("date", displayDateStr); // send pretty date for display
            intent.putExtra("time", selectedTimeSlot);
            startActivity(intent);


        });

        // Default to today if available
        Calendar today = Calendar.getInstance();
        String todayStr = dateFormat.format(today.getTime());
        if (availabilityMap.containsKey(todayStr)) {
            calendarView.setDate(today.getTimeInMillis());
            updateTimeSlots(todayStr);
        }
    }

    private void updateTimeSlots(String dateStr) {
        currentTimeSlots.clear();
        currentTimeSlots.addAll(availabilityMap.get(dateStr));
        timeSlotsAdapter.notifyDataSetChanged();
    }

    private long getDateMillis(int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(year, month, day, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private void loadDummyAvailability() {
        Calendar c = Calendar.getInstance();
        for (int i = 0; i < 7; i++) {
            String dateKey = dateFormat.format(c.getTime());
            int day = c.get(Calendar.DAY_OF_MONTH);

            if (day % 2 == 0) {
                ArrayList<String> slots = new ArrayList<>();
                slots.add("09:00 AM");
                slots.add("10:30 AM");
                slots.add("02:00 PM");
                slots.add("04:00 PM");
                availabilityMap.put(dateKey, slots);
            }
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
    }
}
