package com.trainerlink.ui.theme.models;

public class Trainer {
    private String name;
    private String area;
    private String specialisation;
    private int imageResId;
    private boolean isClickable;

    public Trainer(String name, String area, String specialization, int imageResId, boolean isClickable) {
        this.name = name;
        this.area = area;
        this.specialisation = specialization;
        this.imageResId = imageResId;
        this.isClickable = isClickable;
    }

    public String getName() {
        return name;
    }

    public String getArea() {
        return area;
    }

    public String getSpecialisation() {
        return specialisation;
    }

    public int getImageResId() {
        return imageResId;
    }

    public boolean isClickable() {
        return isClickable;
    }
}
