package com.trainerlink.ui.theme.fragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.trainerlink.R;
import com.trainerlink.ui.theme.activities.TrainerProfileActivity;
import com.trainerlink.ui.theme.models.Trainer;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {

    private GridLayout trainersGrid;
    private Spinner filterCategorySpinner;
    private EditText searchBar;

    private List<Trainer> allTrainers;
    private List<Trainer> filteredTrainers;

    private boolean[] selectedSpecialisations;
    private boolean[] selectedLocations;

    private String[] specialisationOptions;
    private String[] locationOptions;

    private List<String> activeSpecialisationFilters = new ArrayList<>();
    private List<String> activeLocationFilters = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        trainersGrid = view.findViewById(R.id.trainersGrid);
        filterCategorySpinner = view.findViewById(R.id.sortSpinner);
        searchBar = view.findViewById(R.id.searchBar);

        allTrainers = getTrainers();
        filteredTrainers = new ArrayList<>(allTrainers);

        specialisationOptions = getResources().getStringArray(R.array.specialisation_options);
        locationOptions = getResources().getStringArray(R.array.location_options);

        selectedSpecialisations = new boolean[specialisationOptions.length];
        selectedLocations = new boolean[locationOptions.length];

        setupFilterCategorySpinner();
        setupSearchBar();

        displayTrainers(filteredTrainers);

        return view;
    }

    private void setupFilterCategorySpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.filter_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filterCategorySpinner.setAdapter(adapter);

        filterCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = parent.getItemAtPosition(position).toString();

                if (selected.equals("Filter")) {
                    // do nothing or reset spinner only
                }
                else if (selected.equals("Specialisation")) {
                    showMultiChoiceDialog("Select Specialisations", specialisationOptions, selectedSpecialisations, activeSpecialisationFilters);
                }
                else if (selected.equals("Location")) {
                    showMultiChoiceDialog("Select Locations", locationOptions, selectedLocations, activeLocationFilters);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void showMultiChoiceDialog(String title, String[] options, boolean[] selectedArray, List<String> activeFilters) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(title);
        builder.setMultiChoiceItems(options, selectedArray, (dialog, which, isChecked) -> {
            selectedArray[which] = isChecked;
        });

        builder.setPositiveButton("Apply", (dialog, which) -> {
            activeFilters.clear();
            for (int i = 0; i < options.length; i++) {
                if (selectedArray[i]) {
                    activeFilters.add(options[i]);
                }
            }
            applyFiltersAndSearch(searchBar.getText().toString());
            filterCategorySpinner.setSelection(0);  // reset spinner to "Filter"
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> {
            filterCategorySpinner.setSelection(0);
        });

        builder.create().show();
    }

    private void setupSearchBar() {
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                applyFiltersAndSearch(charSequence != null ? charSequence.toString() : "");
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable editable) {}
        });
    }

    // This is the main filtering function: applies both filters + search on full list
    private void applyFiltersAndSearch(String query) {
        query = query.toLowerCase().trim();

        filteredTrainers = new ArrayList<>();
        for (Trainer t : allTrainers) {
            boolean matchesSpecialisation = activeSpecialisationFilters.isEmpty() || activeSpecialisationFilters.contains(t.getSpecialisation());
            boolean matchesLocation = activeLocationFilters.isEmpty() || activeLocationFilters.contains(t.getArea());
            boolean matchesSearch = query.isEmpty() || (
                    t.getName().toLowerCase().contains(query) ||
                            t.getSpecialisation().toLowerCase().contains(query) ||
                            t.getArea().toLowerCase().contains(query)
            );

            if (matchesSpecialisation && matchesLocation && matchesSearch) {
                filteredTrainers.add(t);
            }
        }
        displayTrainers(filteredTrainers);
    }

    private void displayTrainers(List<Trainer> trainers) {
        trainersGrid.removeAllViews();

        for (Trainer trainer : trainers) {
            View trainerView = LayoutInflater.from(getContext()).inflate(R.layout.trainer_item, null);

            ImageView image = trainerView.findViewById(R.id.trainerImage);
            TextView name = trainerView.findViewById(R.id.trainerName);
            TextView area = trainerView.findViewById(R.id.trainerArea);
            TextView spec = trainerView.findViewById(R.id.trainerSpecialization);

            image.setImageResource(trainer.getImageResId());
            name.setText(trainer.getName());
            area.setText(trainer.getArea());
            spec.setText(trainer.getSpecialisation());

            if (trainer.isClickable()) {
                trainerView.setOnClickListener(v -> {
                    Intent intent = new Intent(getActivity(), TrainerProfileActivity.class);
                    intent.putExtra("trainerName", trainer.getName());
                    startActivity(intent);
                });
            }

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);

// Set margins carefully to avoid clipping on sides:
            params.setMargins(24, 32, 24, 32); // 24dp left/right margin on every item

            trainerView.setLayoutParams(params);


            trainerView.setLayoutParams(params);


            trainersGrid.addView(trainerView);
        }
    }

    private List<Trainer> getTrainers() {
        List<Trainer> list = new ArrayList<>();
        list.add(new Trainer("Alice Smith", "Birmingham", "Rehabilitation", R.drawable.trainer1_image, true));
        list.add(new Trainer("Bob Jones", "Coventry", "General Fitness", R.drawable.trainer2_image, false));
        list.add(new Trainer("Charlie Brown", "Walsall", "Beginner Fitness", R.drawable.trainer3_image, false));
        list.add(new Trainer("David Clark", "Edgbaston", "General Fitness", R.drawable.trainer5_image, false));
        list.add(new Trainer("Eva Green", "Birmingham", "Rehabilitation", R.drawable.trainer4_image, false));
        list.add(new Trainer("Frank Hall", "Coventry", "Beginner Fitness", R.drawable.trainer7_image, false));
        list.add(new Trainer("Grace Lee", "Walsall", "General Fitness", R.drawable.trainer6_image, false));
        list.add(new Trainer("Hannah King", "Edgbaston", "Rehabilitation", R.drawable.trainer8_image, false));
        list.add(new Trainer("Ian Miller", "Birmingham", "Beginner Fitness", R.drawable.trainer9_image, false));
        list.add(new Trainer("Jackie Nguyen", "Coventry", "General Fitness", R.drawable.trainer10_image, false));
        list.add(new Trainer("Kyle Owens", "Walsall", "Rehabilitation", R.drawable.trainer11_image, false));
        list.add(new Trainer("Laura Perez", "Edgbaston", "Beginner Fitness", R.drawable.trainer12_image, false));

        return list;
    }
}
