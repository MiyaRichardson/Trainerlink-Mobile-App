package com.trainerlink.ui.theme.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.trainerlink.R;
import com.trainerlink.ui.theme.activities.LogoutActivity;
import com.trainerlink.ui.theme.activities.WorkoutActivity;
import com.trainerlink.ui.theme.adapters.BookingAdapter;
import com.trainerlink.ui.theme.models.Booking;

import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends Fragment {

    private TextView userNameTextView, userEmailTextView, premiumFeaturesTextView;
    private RecyclerView bookingsRecyclerView;
    private BookingAdapter bookingAdapter;
    private List<Booking> bookingList = new ArrayList<>();
    private FirebaseFirestore db;
    private String userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        userEmailTextView = view.findViewById(R.id.userEmailTextView);
        premiumFeaturesTextView = view.findViewById(R.id.premiumFeaturesTextView);
        bookingsRecyclerView = view.findViewById(R.id.bookingsRecyclerView);
        Button upgradeButton = view.findViewById(R.id.upgradePremiumButton);
        Button logoutButton = view.findViewById(R.id.logoutButton);  // NEW

        db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            userId = user.getUid();
            userEmailTextView.setText(user.getEmail());
        }

        premiumFeaturesTextView.setText(
                "Upgrade to Premium to enjoy:\n\n" +
                        "\u2022 Enable Google Fit workout tracking\n" +
                        "\u2022 Priority support\n" +
                        "\u2022 And much more!"
        );

        bookingsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        bookingAdapter = new BookingAdapter(bookingList, getContext());
        bookingsRecyclerView.setAdapter(bookingAdapter);

        loadUserBookings();

        upgradeButton.setOnClickListener(v ->
                startActivity(new Intent(getContext(), WorkoutActivity.class))
        );

        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), LogoutActivity.class);
            startActivity(intent);
        });



        return view;
    }

    private void loadUserBookings() {
        db.collection("bookings")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    bookingList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Log.d("BookingDebug", "Document: " + doc.getData().toString());
                        Booking booking = doc.toObject(Booking.class);
                        booking.setDocumentId(doc.getId());
                        Log.d("BookingDebug", "Parsed booking: " + booking.getTrainerName() + ", " + booking.getSessionDate() + ", " + booking.getSessionTime());
                        bookingList.add(booking);
                    }
                    bookingAdapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to load bookings.", Toast.LENGTH_SHORT).show()
                );
    }
}
