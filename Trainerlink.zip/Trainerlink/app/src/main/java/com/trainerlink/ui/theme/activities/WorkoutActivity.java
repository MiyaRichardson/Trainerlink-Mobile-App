package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.data.DataPoint;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.DataType;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.trainerlink.R;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class WorkoutActivity extends AppCompatActivity {

    private static final int GOOGLE_FIT_SIGN_IN_REQUEST_CODE = 1001;
    private TextView workoutDataText;
    private GoogleSignInClient googleSignInClient;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        workoutDataText = findViewById(R.id.fitnessDataTextView);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(
                        new Scope("https://www.googleapis.com/auth/fitness.activity.read"),
                        new Scope("https://www.googleapis.com/auth/fitness.activity.write")
                )
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, gso);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null && GoogleSignIn.hasPermissions(account, gso.getScopeArray())) {
            fetchWorkoutData();
        } else {
            startActivityForResult(googleSignInClient.getSignInIntent(), GOOGLE_FIT_SIGN_IN_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOOGLE_FIT_SIGN_IN_REQUEST_CODE) {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
            if (account != null && GoogleSignIn.hasPermissions(account, new Scope("https://www.googleapis.com/auth/fitness.activity.read"))) {
                fetchWorkoutData();
            } else {
                Toast.makeText(this, "Google Fit permission is required.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void fetchWorkoutData() {
        Calendar end = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        start.add(Calendar.DAY_OF_YEAR, -7);

        DataReadRequest readRequest = new DataReadRequest.Builder()
                .read(DataType.TYPE_STEP_COUNT_DELTA)
                .setTimeRange(start.getTimeInMillis(), end.getTimeInMillis(), TimeUnit.MILLISECONDS)
                .build();

        Fitness.getHistoryClient(this, GoogleSignIn.getLastSignedInAccount(this))
                .readData(readRequest)
                .addOnSuccessListener(response -> {
                    int totalSteps = 0;
                    for (DataSet dataSet : response.getDataSets()) {
                        for (DataPoint dp : dataSet.getDataPoints()) {
                            totalSteps += dp.getValue(DataType.TYPE_STEP_COUNT_DELTA.getFields().get(0)).asInt();
                        }
                    }
                    workoutDataText.setText("Total steps (last 7 days): " + totalSteps);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to fetch fitness data.", Toast.LENGTH_SHORT).show();
                });
    }
}


