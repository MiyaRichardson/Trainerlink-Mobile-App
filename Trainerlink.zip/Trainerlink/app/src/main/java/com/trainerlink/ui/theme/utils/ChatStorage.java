package com.trainerlink.utils;

import com.trainerlink.ui.theme.models.Message;  // Adjust package for your Message class

import java.util.ArrayList;
import java.util.List;

public class ChatStorage {
    // Stores messages for the "Alice" chat persistently in memory
    public static List<Message> aliceChatMessages = new ArrayList<>();

    // Track if trainer has already responded once
    public static boolean trainerResponded = false;
}
