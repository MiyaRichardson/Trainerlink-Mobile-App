package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.stripe.android.PaymentConfiguration;
import com.stripe.android.model.ConfirmPaymentIntentParams;
import com.stripe.android.model.PaymentMethodCreateParams;
import com.stripe.android.payments.paymentlauncher.PaymentLauncher;
import com.trainerlink.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class PaymentActivity extends AppCompatActivity {

    private static final String BACKEND_URL = "https://5760-2a02-c7c-a897-1600-8c02-1309-372f-789d.ngrok-free.app";
    private static final String PUBLISHABLE_KEY = "pk_test_51RVOqWQpowlkGH76jvcqIZnSin4baj45AYf0GakXLZdbkqUVKHhWCnF90ISWDsMkSMim7mEZnKtpf1YVDKbhZsVr00oCchvfqS";

    private TextView bookingDetailsText;
    private EditText firstNameInput, lastNameInput;
    private com.stripe.android.view.CardInputWidget cardInputWidget;
    private Button payButton;
    private ProgressBar progressBar;
    private CheckBox termsCheckbox;  // Added checkbox

    private String clientSecret;
    private PaymentLauncher paymentLauncher;

    private String trainerName, date, time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        trainerName = getIntent().getStringExtra("trainerName");
        date = getIntent().getStringExtra("date");
        time = getIntent().getStringExtra("time");

        bookingDetailsText = findViewById(R.id.bookingDetailsText);
        firstNameInput = findViewById(R.id.firstNameInput);
        lastNameInput = findViewById(R.id.lastNameInput);
        cardInputWidget = findViewById(R.id.cardInputWidget);
        payButton = findViewById(R.id.payButton);
        progressBar = findViewById(R.id.progressBar);
        termsCheckbox = findViewById(R.id.termsCheckbox);  // Initialize checkbox

        bookingDetailsText.setText("👤 Trainer: " + trainerName + "\n📆 Date: " + date + "\n⏰ Time: " + time);

        PaymentConfiguration.init(getApplicationContext(), PUBLISHABLE_KEY);
        paymentLauncher = PaymentLauncher.Companion.create(this, PUBLISHABLE_KEY, this::onPaymentResult);

        payButton.setOnClickListener(v -> startPayment());
    }

    private void startPayment() {
        // Check if Terms and Conditions checkbox is checked
        if (!termsCheckbox.isChecked()) {
            Toast.makeText(this, "Please agree to the Terms and Conditions to proceed.", Toast.LENGTH_SHORT).show();
            return;
        }

        String firstName = firstNameInput.getText().toString().trim();
        String lastName = lastNameInput.getText().toString().trim();

        if (firstName.isEmpty()) {
            firstNameInput.setError("First name required");
            return;
        }
        if (lastName.isEmpty()) {
            lastNameInput.setError("Last name required");
            return;
        }

        PaymentMethodCreateParams params = cardInputWidget.getPaymentMethodCreateParams();
        if (params == null) {
            Toast.makeText(this, "Enter valid card details 💳", Toast.LENGTH_SHORT).show();
            return;
        }

        setLoading(true);
        createPaymentIntent(params);
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        payButton.setEnabled(!loading);
    }

    private void createPaymentIntent(PaymentMethodCreateParams paymentMethodCreateParams) {
        OkHttpClient client = new OkHttpClient();
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("currency", "gbp");
            jsonBody.put("amount", 1099);
        } catch (JSONException e) {
            e.printStackTrace();
            setLoading(false);
            return;
        }

        RequestBody body = RequestBody.create(jsonBody.toString(), JSON);
        Request request = new Request.Builder()
                .url(BACKEND_URL + "/create-payment-intent")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(PaymentActivity.this, "Network error", Toast.LENGTH_SHORT).show();
                });
            }

            @Override public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    runOnUiThread(() -> {
                        setLoading(false);
                        Toast.makeText(PaymentActivity.this, "Payment failed", Toast.LENGTH_SHORT).show();
                    });
                    return;
                }

                try (ResponseBody responseBody = response.body()) {
                    if (responseBody == null) return;
                    JSONObject json = new JSONObject(responseBody.string());
                    clientSecret = json.getString("clientSecret");

                    runOnUiThread(() -> confirmPayment(paymentMethodCreateParams));
                } catch (JSONException e) {
                    runOnUiThread(() -> {
                        setLoading(false);
                        Toast.makeText(PaymentActivity.this, "Server response error", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    private void confirmPayment(PaymentMethodCreateParams params) {
        if (clientSecret == null) {
            Toast.makeText(this, "Missing client secret", Toast.LENGTH_SHORT).show();
            setLoading(false);
            return;
        }

        ConfirmPaymentIntentParams confirmParams = ConfirmPaymentIntentParams.createWithPaymentMethodCreateParams(
                params, clientSecret
        );

        paymentLauncher.confirm(confirmParams);
    }

    private void onPaymentResult(@NonNull com.stripe.android.payments.paymentlauncher.PaymentResult result) {
        setLoading(false);

        if (result instanceof com.stripe.android.payments.paymentlauncher.PaymentResult.Completed) {
            Toast.makeText(this, "✅ Payment successful!", Toast.LENGTH_SHORT).show();

            // Navigate immediately to success screen
            Intent intent = new Intent(PaymentActivity.this, PaymentSuccessActivity.class);
            intent.putExtra("trainerName", trainerName);
            intent.putExtra("date", date);
            intent.putExtra("time", time);
            startActivity(intent);
            finish();

            // Save booking in background
            saveBookingToFirestore();

        } else if (result instanceof com.stripe.android.payments.paymentlauncher.PaymentResult.Canceled) {
            Toast.makeText(this, "❌ Payment cancelled", Toast.LENGTH_SHORT).show();
        } else if (result instanceof com.stripe.android.payments.paymentlauncher.PaymentResult.Failed) {
            String error = ((com.stripe.android.payments.paymentlauncher.PaymentResult.Failed) result)
                    .getThrowable().getLocalizedMessage();
            Toast.makeText(this, "💥 Payment failed: " + error, Toast.LENGTH_LONG).show();
        }
    }

    private void saveBookingToFirestore() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) return;

        String uid = auth.getCurrentUser().getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> booking = new HashMap<>();
        booking.put("trainerName", trainerName);
        booking.put("date", date);
        booking.put("time", time);

        db.collection("users")
                .document(uid)
                .collection("bookings")
                .add(booking)
                .addOnSuccessListener(documentReference -> Log.d("Booking", "Saved"))
                .addOnFailureListener(e -> Log.e("Booking", "Failed to save", e));
    }
}

