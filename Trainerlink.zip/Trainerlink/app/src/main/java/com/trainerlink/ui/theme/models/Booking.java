package com.trainerlink.ui.theme.models;

public class Booking {
    private String trainerName;
    private String sessionDate;  // rename from date to sessionDate
    private String sessionTime;  // rename from time to sessionTime
    private String documentId;

    public Booking() { }

    public Booking(String trainerName, String sessionDate, String sessionTime) {
        this.trainerName = trainerName;
        this.sessionDate = sessionDate;
        this.sessionTime = sessionTime;
    }

    public String getTrainerName() { return trainerName; }
    public void setTrainerName(String trainerName) { this.trainerName = trainerName; }

    public String getSessionDate() { return sessionDate; }
    public void setSessionDate(String sessionDate) { this.sessionDate = sessionDate; }

    public String getSessionTime() { return sessionTime; }
    public void setSessionTime(String sessionTime) { this.sessionTime = sessionTime; }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
}
