package com.trainerlink.ui.theme.fragments;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.trainerlink.R;
import com.trainerlink.ui.theme.activities.PersonalChatActivity;

public class ChatFragment extends Fragment {

    private LinearLayout chatContainer;
    private TextView noChatsText;
    private Button deleteChatsButton;

    public ChatFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_chat, container, false);

        chatContainer = rootView.findViewById(R.id.chatContainer);
        noChatsText = rootView.findViewById(R.id.noChatsText);
        deleteChatsButton = rootView.findViewById(R.id.deleteChatsButton);

        deleteChatsButton.setOnClickListener(v -> {
            PersonalChatActivity.hasChattedWithAlice = false;
            refreshChatList();
        });

        refreshChatList();

        return rootView;
    }

    private void refreshChatList() {
        chatContainer.removeAllViews();

        if (!PersonalChatActivity.hasChattedWithAlice) {
            // No chats
            noChatsText.setVisibility(View.VISIBLE);
            deleteChatsButton.setVisibility(View.GONE);
        } else {
            // Show chat with Alice
            noChatsText.setVisibility(View.GONE);
            deleteChatsButton.setVisibility(View.VISIBLE);

            TextView aliceChat = new TextView(requireContext());
            aliceChat.setText("Alice");
            aliceChat.setTextSize(18f);
            aliceChat.setTypeface(null, Typeface.BOLD);
            aliceChat.setPadding(20, 30, 20, 30);
            aliceChat.setBackgroundResource(R.drawable.chat_input_bg);
            aliceChat.setGravity(Gravity.CENTER_VERTICAL);
            aliceChat.setOnClickListener(v -> {
                Intent intent = new Intent(requireContext(), PersonalChatActivity.class);
                startActivity(intent);
            });

            chatContainer.addView(aliceChat);
        }
    }
}
