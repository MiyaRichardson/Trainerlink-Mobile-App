package com.trainerlink.ui.theme.models;

public class Review {
    private String reviewerName;
    private String reviewText;
    private String date;

    public Review(String reviewerName, String reviewText, String date) {
        this.reviewerName = reviewerName;
        this.reviewText = reviewText;
        this.date = date;
    }

    public String getReviewerName() {
        return reviewerName;
    }

    public String getReviewText() {
        return reviewText;
    }

    public String getDate() {
        return date;
    }
}
