package com.trainerlink.ui.theme.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.trainerlink.R;

import java.util.HashMap;
import java.util.Map;

public class PaymentSuccessActivity extends AppCompatActivity {

    private TextView successMessage;
    private Button btnBackHome;

    private FirebaseFirestore db;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        successMessage = findViewById(R.id.successMessage);
        btnBackHome = findViewById(R.id.btnBackHome);

        db = FirebaseFirestore.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Get booking details from intent extras
        String trainerName = getIntent().getStringExtra("trainerName");
        String date = getIntent().getStringExtra("date");
        String time = getIntent().getStringExtra("time");

        // Save booking to Firestore
        saveBookingToFirestore(userId, trainerName, date, time);

        // Show success message with emojis
        String message = "Payment Successful!\n\n" +
                "Trainer: " + trainerName + "\n" +
                "Date: " + date + "\n" +
                "Time: " + time;

        successMessage.setText(message);

        btnBackHome.setOnClickListener(v -> {
            Intent intent = new Intent(PaymentSuccessActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void saveBookingToFirestore(String userId, String trainerName, String date, String time) {
        Map<String, Object> booking = new HashMap<>();
        booking.put("userId", userId);
        booking.put("trainerName", trainerName);
        booking.put("sessionDate", date);
        booking.put("sessionTime", time);

        db.collection("bookings")
                .add(booking)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Booking saved successfully!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to save booking. Please try again.", Toast.LENGTH_SHORT).show();
                });
    }
}


